import { defineConfig } from "vite";
import Koa from "koa";
import Router from "@koa/router";
import { loadMFEData } from "./code-gen/index.js";

async function createKoaServer() {
  // create proxy server for file system handling
  const app = new Koa();
  const router = new Router();

  // log incoming requests
  app.use(async (ctx, next) => {
    console.log(`Incoming request: ${ctx.URL.href}`);
    await next();

  });

  router.get("/api/loadMFEData", async (ctx, next) => {
    const results = await loadMFEData();
    ctx.body = results;
    await next();
  });

  router.get("/api/saveAndGenerateComponents", async (ctx, next) => {
    ctx.body = { test: "message" };
    await next();
  });

  app.use(router.routes()).use(router.allowedMethods());
  const server = await app.listen(3001);
return server;

}

export default defineConfig({
  root: "./client",
  server: {
    open: true,
    proxy: {
      "/api/saveAndGenerateComponents": "http://localhost:3001",
      "/api/loadMFEData": "http://localhost:3001",
    },
  },
});

await createKoaServer();
