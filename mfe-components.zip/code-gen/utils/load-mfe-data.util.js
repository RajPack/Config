import fs from "fs/promises";
import path from "path";

// directory path
const dir = "./data-files";

export async function loadMFEData() {
  const files = await fs.readdir(dir);
  const jsonFiles = files.filter(file => path.extname(file) === '.json')

  const result ={}
  const contentPromises = []
  jsonFiles.forEach(async (file) => {
    const fileStrPromise = fs.readFile(path.join(dir, file), {encoding: 'utf-8'});
    contentPromises.push(fileStrPromise)

  })
  const fileDataArr = await Promise.all(contentPromises)
  fileDataArr.forEach((fileData, index) => {
    const file = jsonFiles[index];
    result[file] = JSON.parse(fileData)
  })
  return result;
}
