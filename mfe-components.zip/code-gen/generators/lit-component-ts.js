
export default function (
  /** @type {import('plop').NodePlopAPI} */
  plop
  ) {
plop.setGenerator('lit-wc', {
    description: 'generate lit web component',
    prompts:[],
    actions:  function(data) {
      const kebabCase = plop.getHelper('kebabCase')
      const pascalCase = plop.getHelper('pascalCase')
      return [
        {
        type: 'add',
        path: 'generated/components/{{tagName}}/{{tagName}}.js',
        templateFile: './src/templates/lit-component-ts.template.hbs',
        data: {...data, 
          className: pascalCase(data.name), 
          tagName: kebabCase(data.name)
        }
    }
    ]
    }
});

};