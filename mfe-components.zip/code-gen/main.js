import nodePlop from 'node-plop';
// load an instance of plop from a plopfile
const plop = await nodePlop(`./generators.js`);
// get a generator by name
const basicAdd = plop.getGenerator('lit-wc');

// run all the generator actions using the data specified
 basicAdd.runActions({name: 'this is a test'})