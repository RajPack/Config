import { TAG } from "../interfaces/tag.interface";

export async function fetchMFEData() {
  const resp = await fetch("/api/loadMFEData");
  const data = await resp.json();
  return Object.keys(data).map((mfename) => {
    return {
      mfe: mfename.split(".").slice(0, -1).join(" "),
      tags: data[mfename as keyof typeof data].tags.map((tag: TAG) => ({
        ...tag,
        sealed: true,
      })),
    };
  });
}
