import { MFECOMPONENTMAP } from "../interfaces/component.interface";
import { TAG, TAGSIZE } from "../interfaces/tag.interface";
import { getCurrentTagZIndex } from "./interact.util";

export function generateNewTag(id: number, name?: string): TAG {
  return {
    id: id,
    name: name ?? `app-component${id}`,
    properties: [],
    attributes: [],
    events: [],
    sealed: false,
  };
}

export function reconcileTagPosition(
  tags: TAG[],
  currentTagPosition: { [id: number]: TAGSIZE }
) {
  const newTagPosition: { [id: number]: TAGSIZE } = {};
  tags.forEach((tag, i) => {
    const id = tag.id;
    newTagPosition[id] = currentTagPosition[id] || {
      height: 100,
      width: 100,
      x: i * 5,
      y: i * 15,
      zIndex: getCurrentTagZIndex(),
    };
  });
  return newTagPosition;
}

export function reconcileMFEComponents(
  tags: TAG[],
  mfeMap: MFECOMPONENTMAP
): MFECOMPONENTMAP {
  tags.forEach((tag) => {
    mfeMap[tag.id] = mfeMap[tag.id] ?? {
      id: tag.id,
      tag: tag.name,
      sealed: tag.sealed,
      properties: tag.properties || [],
      state: [],
      members: [],
      eventHandlers: [],
      parentPropertyMap: {},
      parentEventMap: {},
      parentComponent: undefined,
    };
  });
  return mfeMap;
}
