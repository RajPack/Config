import interact from "interactjs";
import { TAGSIZE } from "../interfaces/tag.interface";

let activeInteractables: any[] = [];
let maxCanvasZIndex = 0;

export function getCurrentTagZIndex() {
  return maxCanvasZIndex;
}

export function makeTagInteractable(
  tag: HTMLElement,
  tagPosition: { [id: number]: TAGSIZE },
  parent: HTMLElement
) {
  const interactable = interact(tag)
    .draggable({
      inertia: true,
      modifiers: [
        interact.modifiers.restrict({
          restriction: parent,
          endOnly: true,
        }),
      ],
      listeners: {
        move(event) {
          const tagElem = event.target;
          const id = Number(tagElem.getAttribute("data-id"));
          const currentPos = tagPosition[id];
          currentPos.x = currentPos.x + event.dx;
          currentPos.y = currentPos.y + event.dy;
          tagElem.style.top = currentPos.y + "px";
          tagElem.style.left = currentPos.x + "px";
        },
      },
    })
    .resizable({
      inertia: {
        resistance: 30,
        minSpeed: 200,
        endSpeed: 100,
      },
      edges: { top: true, left: true, bottom: true, right: true },
      listeners: {
        move: function (event) {
          let { x, y } = event.target.dataset;
          console.log(x, y);

          x = (parseFloat(x) || 0) + event.deltaRect.left;
          y = (parseFloat(y) || 0) + event.deltaRect.top;

          const tagElem = event.target;
          const id = Number(tagElem.getAttribute("data-id"));
          const currentPos = tagPosition[id];
          currentPos.x = currentPos.x + event.deltaRect.left;
          currentPos.y = currentPos.y + event.deltaRect.top;
          currentPos.width = event.rect.width;
          currentPos.height = event.rect.height;
          tagElem.style.top = currentPos.y + "px";
          tagElem.style.left = currentPos.x + "px";

          Object.assign(tagElem.style, {
            width: `${event.rect.width}px`,
            height: `${event.rect.height}px`,
          });

          Object.assign(event.target.dataset, { x, y });
        },
      },
    })
    .dropzone({
      overlap: 0.95,
      accept: ".draggable-tag",
      ondropdeactivate: function (event) {
        const isNull = !event.currentTarget;
        if (isNull) {
          event.target.dispatchEvent(
            new CustomEvent("parentChange", {
              bubbles: true,
              detail: {
                id: Number(event.relatedTarget.getAttribute("data-id")),
                parentId: null,
              },
            })
          );
        }
      },
      ondrop: function (event) {
        console.log(event.relatedTarget, " was dropped into ", event.target);
        const id = Number(event.relatedTarget.getAttribute("data-id"));
        const pos = tagPosition[id];
        const parentZIndex = event.target.style.zIndex;
        const targetZIndex = (parentZIndex ?? 0) + 1;
        maxCanvasZIndex =
          maxCanvasZIndex > targetZIndex ? maxCanvasZIndex : targetZIndex;
        event.relatedTarget.style.zIndex = targetZIndex;
        pos.zIndex = targetZIndex;
        event.target.dispatchEvent(
          new CustomEvent("parentChange", {
            bubbles: true,
            detail: {
              parentId: Number(event.target.getAttribute("data-id")),
              id: id,
            },
          })
        );
      },
    });

  activeInteractables.push(interactable);
}

export function deactivateInteractables() {
  activeInteractables.forEach((inte) => {
    inte.unset();
    inte.off();
  });
  activeInteractables = [];
}
