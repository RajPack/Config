import { PROPERTY } from "./tag.interface";

export interface MFECOMPONENT {
  id: number;
  tag: string;
  properties: PROPERTY[];
  state: PROPERTY[];
  members: PROPERTY[];
  eventHandlers: EVENTHANDLERS[];
  sealed: boolean;
  parentPropertyMap: Record<string, string>;
  parentEventMap: Record<string, string>;
  parentComponent?: MFECOMPONENT;
}

type EVENTHANDLERS = {
  name: string;
  type: string;
};

export type MFECOMPONENTMAP = {
  [id: number]: MFECOMPONENT;
};
