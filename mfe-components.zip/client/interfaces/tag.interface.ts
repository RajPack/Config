export interface TAG {
  id: number;
  name: string;
  attributes: ATTRIBUTE[];
  properties: PROPERTY[];
  events: EVENT[];
  sealed: boolean;
}

export type ATTRIBUTE = {
  name: string;
  type: string;
  default: any;
};

export type PROPERTY = ATTRIBUTE;
export type EVENT = {
  name: string;
};

export interface TAGSIZE {
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
}

export interface MFEDATA {
  mfe: string;
  tags: TAG[];
}
