import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js'
import { TAG } from '../interfaces/tag.interface';

@customElement('app-wc-canvas-item')
export class AppWcCanvasItem extends LitElement {
  static styles = [
    css`
      :host {
        display: block;
      }
    `
  ];
  @property({attribute: false}) tag!: TAG

  render() {

    return html`
      <div class="tag" >
        <span class="title">${this.tag.name}</span>
      </div>
    `;
  }
}
