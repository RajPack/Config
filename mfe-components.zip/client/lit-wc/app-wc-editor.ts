import { LitElement, html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { MFECOMPONENT } from "../interfaces/component.interface";
import { ifDefined } from "lit/directives/if-defined.js";

@customElement("app-wc-editor")
export class AppWcEditor extends LitElement {
  static styles = [
    css`
      :host {
        display: block;
        box-shadow: rgb(204, 204, 204) 6px 12px 10px 6px;
        width: 326px;
        font-size: 12px;
      }
      .editor {
        padding: 4px;
        height: 100%;
      }
      h4 {
        padding: 6px;
        margin: 0;
      }
      .caption {
        margin-left: 6px;
      }
      .no-data {
        margin: 500px 5px 0px 5px;
      }
      .divider-line {
        border-bottom: 1px solid rgba(0, 0, 0, 0.1);
      }
      .section {
        padding: 12px;
      }
      .section-title {
        font-weight: bold;
        display: flex;
        justify-content: space-between;
      }
      .info-row {
        display: flex;
        justify-content: space-between;
        padding: 6px;
      }
      input {
        font-size: 11px;
        border: 1px solid lightgray;
        border-radius: 2px;
        padding: 3px 8px;
      }
      .add-btn {
        background: white;
        outline: none;
        fill: var(--color-icon, #333333);
        color: var(--color-icon, #333333);
        padding: 5px 10px;
        border: none;
        border-radius: 3px;
      }
      .add-btn:hover {
        cursor: pointer;
        background: rgb(245, 245, 245);
      }
    `,
  ];

  @property({ attribute: false }) component?: MFECOMPONENT;

  render() {
    console.log(this.component);
    return html`
      <div class="editor">
        <h4>Configure MFE</h4>
        <div class="caption">Configure MFE properties and mappings</div>
        <div class="divider-line" style="margin-bottom: 32px;"></div>
        ${this.renderComponentDetails()}
      </div>
    `;
  }
  private renderComponentDetails() {
    if (!this.component) {
      return html`<div class="no-data">
        Please select a component to configure.
      </div> `;
    }

    return [
      this.renderComponentBasicInfo(),
      this.renderComponentMembers(),
      this.renderComponentEventHandlers(),
      this.renderComponentProperyMaps(),
      this.renderComponentEventMaps(),
    ];
  }

  private renderComponentBasicInfo() {
    return html`
      <div class="section">
        <div class="section-title">About Component</div>
        <div class="info-row">
          <label for="">Tag Name:</label>
          <input
            type="text"
            name="name"
            .value=${this.component!.tag}
            disabled=${ifDefined(this.component!.sealed || undefined)}
          />
        </div>
        <div class="info-row">
          <label for="">Parent Component:</label>
          <input
            type="text"
            name="name"
            .value=${this.component?.parentComponent?.tag || "None"}
            disabled
          />
        </div>
      </div>

      <div class="divider-line"></div>
    `;
  }
  private renderComponentMembers() {
    return html`
      <div class="section">
        <div class="section-title">
          Properties ${this.component!.sealed ? "" : this.renderAddButton()}
        </div>
      </div>
      <div class="divider-line"></div>
    `;
  }

  private renderComponentEventHandlers() {
    return html`
      <div class="section">
        <div class="section-title">
          Event Handlers ${this.component!.sealed ? "" : this.renderAddButton()}
        </div>
      </div>
      <div class="divider-line"></div>
    `;
  }

  private renderComponentEventMaps() {
    return html`
      <div class="section">
        <div class="section-title">
          Map Events to Parent Component Handlers
          ${!this.component!.parentComponent ? "" : this.renderAddButton()}
        </div>
      </div>
      <div class="divider-line"></div>
    `;
  }

  private renderComponentProperyMaps() {
    return html`
      <div class="section">
        <div class="section-title">
          Map Properties to Parent Component Fields
          ${!this.component!.parentComponent ? "" : this.renderAddButton()}
        </div>
      </div>
      <div class="divider-line"></div>
    `;
  }

  private renderAddButton() {
    return html`
      <button class="add-btn">
        <span class="svg-container"
          ><svg
            class="svg"
            xmlns="http://www.w3.org/2000/svg"
            width="12"
            height="12"
            viewBox="0 0 12 12"
          >
            <path
              fill="#000"
              fill-opacity="1"
              fill-rule="nonzero"
              stroke="none"
              d="M5.5 5.5v-5h1v5h5v1h-5v5h-1v-5h-5v-1h5z"
            ></path></svg
        ></span>
      </button>
    `;
  }
}
