import { LitElement, html, css, PropertyValueMap } from "lit";
import { customElement, property, queryAll } from "lit/decorators.js";
import { MFEDATA, TAG } from "../interfaces/tag.interface";
import { generateNewTag } from "../utils/tags.utils";
import { repeat } from "lit/directives/repeat.js";

@customElement("app-wc-explorer")
export class AppWcExplorer extends LitElement {
  static styles = [
    css`
      .btn {
        appearance: none;
        backface-visibility: hidden;
        background-color: #2f80ed;
        border-radius: 10px;
        border-style: none;
        box-shadow: none;
        box-sizing: border-box;
        color: #fff;
        cursor: pointer;
        display: inline-block;
        font-size: 11px;
        font-weight: 500;
        height: 30px;
        letter-spacing: normal;
        line-height: 1;
        outline: none;
        overflow: hidden;
        padding: 8px 15px;
        position: relative;
        text-align: center;
        text-decoration: none;
        transform: translate3d(0, 0, 0);
        transition: all 0.3s;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        vertical-align: top;
        white-space: nowrap;
      }

      .btn:hover {
        background-color: #1366d6;
        box-shadow: rgba(0, 0, 0, 0.05) 0 5px 30px,
          rgba(0, 0, 0, 0.05) 0 1px 4px;
        opacity: 1;
        transform: translateY(0);
        transition-duration: 0.35s;
      }

      .btn:hover:after {
        opacity: 0.5;
      }

      .btn:active {
        box-shadow: rgba(0, 0, 0, 0.1) 0 3px 6px 0,
          rgba(0, 0, 0, 0.1) 0 0 10px 0, rgba(0, 0, 0, 0.1) 0 1px 4px -1px;
        transform: translateY(2px);
        transition-duration: 0.35s;
      }

      .btn:active:after {
        opacity: 1;
      }
    `,
    css`
      :host {
        display: block;
        box-shadow: rgb(204, 204, 204) -5px 9px 10px 5px;
        font-size: 12px;
        width: 326px;
      }
      .explorer {
        padding: 4px;
      }
      .caption {
        margin-left: 6px;
      }
      .mfe-tag {
        padding: 0px;
      }
      .mfe-tag .mfe-tag-name {
        padding: 6px 12px;
        font-weight: bold;
        height: 32px;
        box-sizing: border-box;
      }
      .mfe-tag .tag-info {
        background: white;
        padding: 6px 24px;
        height: 32px;
        box-sizing: border-box;
        user-select: none;
      }
      .mfe-tag .tag-info:hover {
        cursor: pointer;
        background-color: #daebf7;
      }
      h4 {
        padding: 6px;
        margin: 0;
      }
      .action-container {
        margin: 12px 0px;
        display: flex;
        justify-content: center;
      }
      button {
        font-size: 12px;
      }
      .divider-line {
        border-bottom: 1px solid rgba(0, 0, 0, 0.1);
      }
    `,
  ];

  @queryAll(".tag-info") draggableTags!: HTMLElement[];
  @property({ type: Boolean }) hasRootTag = false;
  @property({ type: Number }) lastId = 0;
  @property({ attribute: false }) MFEData: MFEDATA[] = [];

  onNewTag() {
    this.dispatchEvent(
      new CustomEvent<TAG>("add-tag", {
        detail: generateNewTag(this.lastId + 1),
      })
    );
  }

  addTag(tag: TAG) {
    this.dispatchEvent(
      new CustomEvent<TAG>("add-tag", {
        detail: { ...tag, id: this.lastId + 1 },
      })
    );
  }

  render() {
    return html`
      <div class="explorer">
        <h4>Explorer</h4>
        <div class="caption">Browse, pick and drag components</div>

        ${this.renderActions()}
        <div class="divider-line"></div>
        ${this.renderMFEData()}
      </div>
    `;
  }

  private renderActions() {
    return html`
      <div class="action-container">
        <button class="btn" @click=${this.onNewTag}>Add New Component</button>
      </div>
    `;
  }

  private renderMFEData() {
    return html`
      ${repeat(
        this.MFEData,
        (data) => data.mfe,
        (data) => html`
          <div class="mfe-tag">
            <div class="mfe-tag-name">${data.mfe}</div>

            ${repeat(
              data.tags,
              (tag) => tag.name,
              (tag) =>
                html`
                  <div class="tag-info" @click=${() => this.addTag(tag)}>
                    ${tag.name}
                  </div>
                `
            )}
            <div class="divider-line"></div>
          </div>
        `
      )}
    `;
  }
}
