import { LitElement, html, css, PropertyValueMap } from "lit";
import {
  customElement,
  property,
  query,
  queryAll,
  state,
} from "lit/decorators.js";
import { TAG, TAGSIZE } from "../interfaces/tag.interface";
import { repeat } from "lit/directives/repeat.js";
import { reconcileTagPosition } from "../utils/tags.utils";
import { styleMap } from "lit/directives/style-map.js";
import {
  deactivateInteractables,
  makeTagInteractable,
} from "../utils/interact.util";

@customElement("app-wc-canvas")
export class AppWcCanvas extends LitElement {
  static styles = [
    css`
      :host {
        display: block;
      }
      .canvas-area {
        position: relative;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        overflow: auto;
        background-color: #e5e5e5;
      }
      .draggable-tag {
        font-size: 12px;
        position: absolute;
        min-width: 100px;
        min-height: 100px;
        min-height: 6.5em;
        margin: 1rem 0 0 1rem;
        color: black;
        border-radius: 0.75em;
        padding: 12px;
        touch-action: none;
        user-select: none;
        border: 1px solid darkgray;
        background-color: white;
      }
      .draggable-tag.sealed {
        background: #fffde7;
      }
      .draggable-tag.active {
        border: 1px solid #e83434;
        box-shadow: rgb(204, 204, 204) 3px 6px 5px 3px;
      }
      .draggable-tag:hover {
        box-shadow: rgb(204, 204, 204) 6px 12px 10px 6px;

        /* background-color: #29e; */
        /* color: white; */
      }
    `,
  ];

  @queryAll(".draggable-tag") tagElems!: HTMLElement[];
  @query(".canvas-area") parentContainer!: HTMLElement;
  @property({ attribute: false }) tags: TAG[] = [];

  @state() tagPosition: { [id: number]: TAGSIZE } = {};
  @state() selectedTagId = 0;

  protected willUpdate(
    _changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>
  ): void {
    super.willUpdate(_changedProperties);
    if (_changedProperties.has("tags")) {
      this.tagPosition = reconcileTagPosition(this.tags, this.tagPosition);
    }
  }

  protected updated(
    _changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>
  ): void {
    super.updated(_changedProperties);
    deactivateInteractables();
    this.tagElems.forEach((tag) =>
      makeTagInteractable(tag, this.tagPosition, this.parentContainer)
    );
  }

  onParentChange(e: CustomEvent<{ id: number; parentId: number }>) {
    this.dispatchEvent(
      new CustomEvent("parentChange", { detail: e.detail, bubbles: true })
    );
  }
  onTagSelection(id: number) {
    this.selectedTagId = id;
    this.dispatchEvent(
      new CustomEvent("tagSelect", { detail: id, bubbles: true })
    );
  }

  render() {
    return html`
      <div class="canvas-area" @parentChange=${this.onParentChange}>
        ${repeat(
          this.tags,
          (tag) => tag.id,
          (tag) => {
            const pos = this.tagPosition[tag.id];
            const styles = {
              top: pos.y + "px",
              left: pos.x + "px",
              width: pos.width + "px",
              height: pos.height + "px",
              zIndex: pos.zIndex,
            };
            return html`
              <div
                class="draggable-tag ${this.selectedTagId === tag.id
                  ? "active"
                  : ""}  ${tag.sealed ? "sealed" : ""}"
                data-id=${tag.id}
                style=${styleMap(styles)}
                @click=${() => this.onTagSelection(tag.id)}
              >
                <b>Component:</b>
                <div>${tag.name}</div>
              </div>
            `;
          }
        )}
      </div>
    `;
  }
}
