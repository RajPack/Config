import { LitElement, html, css, PropertyValueMap } from "lit";
import { customElement, query, state } from "lit/decorators.js";
import { MFEDATA, TAG } from "../interfaces/tag.interface";
import { fetchMFEData } from "../services/data.service";
import { MFECOMPONENTMAP } from "../interfaces/component.interface";
import { reconcileMFEComponents } from "../utils/tags.utils";
import { AppWcCanvas } from ".";

@customElement("app-main")
export class AppMain extends LitElement {
  static styles = [
    css`
      :host {
        display: block;
      }
      .app-main {
        display: flex;
        height: calc(100vh - 47px);
      }
      app-wc-canvas {
        flex-grow: 1;
      }
      header {
        box-shadow: rgb(204, 204, 204) 0px 2px 8px -1px;
        padding: 12px;
        display: flex;
        justify-content: space-between;
      }
      .btn {
        appearance: none;
        background-color: #2ea44f;
        border: 1px solid rgba(27, 31, 35, 0.15);
        border-radius: 6px;
        box-shadow: rgba(27, 31, 35, 0.1) 0 1px 0;
        box-sizing: border-box;
        color: #fff;
        cursor: pointer;
        padding: 6px;
      }
      .btn:hover {
        background: rgb(44, 151, 75);
      }
      .generate {
        margin-left: 24px;
      }
    `,
  ];

  @state() tags: TAG[] = [];
  @state() MFEData: MFEDATA[] = [];
  @state() mfeComponentMap: MFECOMPONENTMAP = {};
  @state() selectedMFEComponentId = 0;

  async connectedCallback(): Promise<void> {
    super.connectedCallback();
    const data = await fetchMFEData();
    this.MFEData = data;
  }

  private onNewComponent(e: CustomEvent<TAG>) {
    const tag = e.detail;
    console.log(tag);
    this.tags.push(tag);
    this.tags = [...this.tags];
    this.mfeComponentMap = reconcileMFEComponents(
      this.tags,
      this.mfeComponentMap
    );
  }

  private onTagSelect(e: CustomEvent<number>) {
    this.selectedMFEComponentId = e.detail;
  }

  private onParentChange(e: CustomEvent<{ id: number; parentId: number }>) {
    const { id, parentId } = e.detail;
    const mfe = this.mfeComponentMap[id];
    const parent = parentId ? this.mfeComponentMap[parentId] : undefined;
    mfe.parentComponent = parent;
    this.mfeComponentMap[id] = { ...mfe };
    this.requestUpdate();
  }

  render() {
    return html` <header>
        <span>MFE Component Model Generator</span>
        <span
          >Load, Configure and Generate MFE
          <button class="btn generate">Generate MFE Components</button></span
        >
      </header>
      <div class="app-main">
        <app-wc-explorer
          .lastId=${this.tags[this.tags.length - 1]?.id || 0}
          .hasRootTag=${this.tags.length > 0}
          .MFEData=${this.MFEData}
          @add-tag=${this.onNewComponent}
        ></app-wc-explorer>
        <app-wc-canvas
          .tags=${this.tags}
          @tagSelect=${this.onTagSelect}
          @parentChange=${this.onParentChange}
        ></app-wc-canvas>
        <app-wc-editor
          .component=${this.mfeComponentMap[this.selectedMFEComponentId]}
        ></app-wc-editor>
      </div>`;
  }
}
