import litComponentGenerator from './code-gen/generators/lit-component-ts.js'

export default function (
  /** @type {import('plop').NodePlopAPI} */
  plop
  ) {

  litComponentGenerator(plop)

  }
